import{p as R,a as V,m as ue,e as _e,w as me,x as pe,y as Ue,z as Oe,u as se,B as fe,D as Q,C as ge}from"./worker-shared-CnoKe7Au.js";let Xe="useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict",Ae=e=>crypto.getRandomValues(new Uint8Array(e)),ve=(e,t,r)=>{let n=256-256%e.length;if(n===256){let T=e.length-1;return(E=t)=>{if(!E)return"";let s="";for(;;){let o=r(E),u=E;for(;u--;)if(s+=e[o[u]&T],s.length>=E)return s}}}let i=Math.ceil(1.6*256*t/n);return(T=t)=>{if(!T)return"";let E="";for(;;){let s=r(i),o=i;for(;o--;)if(s[o]<n&&(E+=e[s[o]%e.length],E.length>=T))return E}}},Ie=(e,t=21)=>ve(e,t|0,Ae),rt=(e=21)=>{let t="",r=crypto.getRandomValues(new Uint8Array(e|=0));for(;e--;)t+=Xe[r[e]&63];return t};const q=["zh-CN","en-US","es-419","fr-FR","ja-JP","de-DE","ko-KR","it-IT","pt-BR","hi-IN"],J=[{code:"en",name:"English",locale:"en-US"},{code:"es",name:"Spanish",locale:"es-419"},{code:"fr",name:"French",locale:"fr-FR"},{code:"ja",name:"Japanese",locale:"ja-JP"},{code:"de",name:"German",locale:"de-DE"},{code:"ko",name:"Korean",locale:"ko-KR"},{code:"it",name:"Italian",locale:"it-IT"},{code:"zh",name:"Chinese",locale:"zh-CN"},{code:"pt",name:"Portuguese",locale:"pt-BR"},{code:"hi",name:"Hindi",locale:"hi-IN"}],he={"zh-CN":{code:"zh-CN",shortCode:"中",nativeName:"简体中文",htmlLang:"zh-CN",promptName:"Simplified Chinese as used in mainland China",voice:"Use contemporary, warm, direct Simplified Chinese. Address the user as “你”. Avoid translated sentence patterns, formal notices, and unnecessary linking phrases."},"en-US":{code:"en-US",shortCode:"EN",nativeName:"English",htmlLang:"en-US",promptName:"American English",voice:"Use concise, contemporary American English. Sound helpful and human, not promotional or bureaucratic."},"es-419":{code:"es-419",shortCode:"ES",nativeName:"Español",htmlLang:"es-419",promptName:"neutral Latin American Spanish",voice:"Use natural, widely understood Latin American Spanish. Address the user with “tú”. Avoid literal translations, stiff connectors, and Spain-only wording."},"fr-FR":{code:"fr-FR",shortCode:"FR",nativeName:"Français",htmlLang:"fr-FR",promptName:"French as used in France",voice:"Use natural contemporary French from France. Address the user with “vous”; keep the tone warm, clear, and restrained rather than formal or promotional."},"ja-JP":{code:"ja-JP",shortCode:"日",nativeName:"日本語",htmlLang:"ja-JP",promptName:"Japanese as used in Japan",voice:"Use natural modern Japanese in a friendly です・ます style. Prefer concise product language and avoid calques, excessive subjects, and ceremonial politeness."},"de-DE":{code:"de-DE",shortCode:"DE",nativeName:"Deutsch",htmlLang:"de-DE",promptName:"German as used in Germany",voice:"Use natural contemporary German from Germany. Address the user with “du”. Keep sentences direct and avoid nominal style, anglicized syntax, and bureaucratic wording."},"ko-KR":{code:"ko-KR",shortCode:"한",nativeName:"한국어",htmlLang:"ko-KR",promptName:"Korean as used in South Korea",voice:"Use natural contemporary Korean in a friendly 해요체. Keep interface wording concise and avoid translated word order, excessive nouns, and formal administrative language."},"it-IT":{code:"it-IT",shortCode:"IT",nativeName:"Italiano",htmlLang:"it-IT",promptName:"Italian as used in Italy",voice:"Use natural contemporary Italian from Italy. Address the user with “tu”; keep it clear, warm, and conversational without filler or literal translation patterns."},"pt-BR":{code:"pt-BR",shortCode:"PT",nativeName:"Português",htmlLang:"pt-BR",promptName:"Brazilian Portuguese",voice:"Use natural contemporary Brazilian Portuguese. Address the user with “você”. Prefer everyday phrasing and avoid European Portuguese forms, literal syntax, and stiff connectors."},"hi-IN":{code:"hi-IN",shortCode:"हि",nativeName:"हिन्दी",htmlLang:"hi-IN",promptName:"standard contemporary Hindi as used in India",voice:"Use natural contemporary Hindi in Devanagari. Address the user respectfully with “आप”. Prefer familiar product wording and avoid word-for-word English syntax or overly Sanskritized prose."}};function ye(e,t="zh-CN"){return typeof e!="string"?t:q.includes(e)?e:t}function Re(e){return J.find(t=>t.code===e)||J[0]}function ot(e){return he[ye(e)]}const Se=.85,we=.6,Fe=1.2;var De={},N=(e,t,r)=>new Promise((n,i)=>{var T=o=>{try{s(r.next(o))}catch(u){i(u)}},E=o=>{try{s(r.throw(o))}catch(u){i(u)}},s=o=>o.done?n(o.value):Promise.resolve(o.value).then(T,E);s((r=r.apply(e,t)).next())});const K=De.LLC_DATA_DIR||R.resolve(process.cwd(),"data"),I=R.join(K,"config.json"),h=R.join(K,"secrets.json"),F=R.join(K,"provider-save.transaction.json"),C=[{id:"openai",name:"OpenAI",kind:"openai",baseUrl:"https://api.openai.com/v1",model:"",apiKeySecret:"providers.openai.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"anthropic",name:"Anthropic",kind:"anthropic",baseUrl:"https://api.anthropic.com/v1",model:"",apiKeySecret:"providers.anthropic.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"gemini",name:"Google Gemini",kind:"gemini",baseUrl:"https://generativelanguage.googleapis.com/v1beta",model:"",apiKeySecret:"providers.gemini.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"deepseek",name:"DeepSeek",kind:"deepseek",baseUrl:"https://api.deepseek.com",model:"",apiKeySecret:"providers.deepseek.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"kimi",name:"Moonshot / Kimi",kind:"kimi",baseUrl:"https://api.moonshot.ai/v1",model:"",apiKeySecret:"providers.kimi.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}}],H="custom",G="default",Z=12;function it(e,t){return{id:H,name:e,kind:"openai",baseUrl:t,model:"",apiKeySecret:"providers.custom.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}}}function Ce(e){if(typeof e!="string"||!e||e.length>300)return!1;try{const t=new URL(e);return(t.protocol==="http:"||t.protocol==="https:")&&!t.username&&!t.password}catch{return!1}}function Pe(e){return e.kind==="openai"&&e.apiKeySecret==="providers.custom.apiKey"&&typeof e.name=="string"&&e.name.trim().length>0&&e.name.length<=60&&Ce(e.baseUrl)}function be(e){if(e.profiles===void 0){if(e.activeProfile!==void 0&&e.activeProfile!==G)throw new Error("The active profile is invalid");return}if(!Array.isArray(e.profiles)||!e.profiles.length||e.profiles.length>Z)throw new Error("The profile list is invalid");const t=new Set;for(const r of e.profiles){const n=_(r);if(typeof n.id!="string"||!/^[a-z0-9]{1,24}$/u.test(n.id)||t.has(n.id))throw new Error("A profile id is invalid");if(typeof n.name!="string"||n.name.length>40||typeof n.createdAt!="string")throw new Error("A profile is incomplete");if(n.uiLocale!==void 0&&!q.includes(n.uiLocale))throw new Error("A profile language is invalid");n.learning!==void 0&&_(n.learning),t.add(n.id)}if(e.activeProfile!==void 0&&!t.has(e.activeProfile))throw new Error("The active profile is invalid")}const j={setupComplete:!1,ui:{locale:"zh-CN"},learning:{targetLanguage:"English",targetLanguageCode:"en",proficiency:"B1",correctionLevel:"balanced",speechRate:Se,reviewInConversation:!0},llm:{defaultProvider:"",temperature:.7},webLookup:{enabled:!1,provider:"selected",timeoutMs:8e3,maxResults:5},server:{host:"127.0.0.1",port:4174},providers:C};function _(e){if(!e||typeof e!="object"||Array.isArray(e))throw new Error("Expected an object");return e}function S(e){const t=_(e),r=_(t.ui),n=_(t.learning),i=_(t.llm),T=_(t.webLookup),E=_(t.server);if(typeof t.setupComplete!="boolean")throw new Error("setupComplete must be boolean");if(!q.includes(r.locale))throw new Error("Unsupported interface locale");if(typeof n.targetLanguage!="string"||typeof n.targetLanguageCode!="string"||typeof n.proficiency!="string")throw new Error("Learning preferences are incomplete");if(!["light","balanced","intensive"].includes(n.correctionLevel))throw new Error("Unsupported correction level");if(n.speechRate!==void 0&&(typeof n.speechRate!="number"||!Number.isFinite(n.speechRate)||n.speechRate<we||n.speechRate>Fe))throw new Error("Speech rate is invalid");if(n.reviewInConversation!==void 0&&typeof n.reviewInConversation!="boolean")throw new Error("Review setting is invalid");if(n.voiceInput!==void 0&&n.voiceInput!=="browser"&&n.voiceInput!=="model")throw new Error("Voice input setting is invalid");if(n.listenFirst!==void 0&&typeof n.listenFirst!="boolean")throw new Error("Listening setting is invalid");if(n.variant!==void 0&&(typeof n.variant!="string"||n.variant.length>12))throw new Error("Language variety is invalid");if(n.register!==void 0&&!["neutral","casual","formal"].includes(n.register))throw new Error("Register setting is invalid");if(i.reviewProvider!==void 0&&typeof i.reviewProvider!="string")throw new Error("Review model setting is invalid");if(t.usage!==void 0){const c=_(t.usage).monthlyLimit;if(c!==void 0&&(typeof c!="number"||!Number.isFinite(c)||c<0||c>1e5))throw new Error("Spending reminder is invalid")}if(be(t),!Number.isFinite(i.temperature)||typeof i.defaultProvider!="string")throw new Error("Model settings are incomplete");if(T.provider!=="selected"||typeof T.enabled!="boolean")throw new Error("Web lookup settings are invalid");if(!Number.isInteger(T.timeoutMs)||T.timeoutMs<2e3||T.timeoutMs>2e4)throw new Error("Web lookup timeout is invalid");if(!Number.isInteger(T.maxResults)||T.maxResults<1||T.maxResults>10)throw new Error("Web lookup result limit is invalid");if(typeof E.host!="string"||!Number.isInteger(E.port)||E.lan!==void 0&&typeof E.lan!="boolean")throw new Error("Server settings are invalid");if(t.memory!==void 0&&_(t.memory).consolidate!==void 0&&typeof _(t.memory).consolidate!="boolean")throw new Error("Memory settings are invalid");if(!Array.isArray(t.providers))throw new Error("The provider list does not match the current schema");const s=t.providers.find(c=>c?.id===H);if(t.providers.length!==C.length+(s?1:0))throw new Error("The provider list does not match the current schema");if(s&&!Pe(s))throw new Error("The custom endpoint is invalid");const u=(s?[...C,s]:C).map(c=>{const l=_(t.providers.find(L=>L?.id===c.id));if(l.name!==c.name||l.kind!==c.kind||l.baseUrl!==c.baseUrl||l.apiKeySecret!==c.apiKeySecret)throw new Error(`Provider identity is invalid: ${c.id}`);if(typeof l.model!="string"||typeof l.enabled!="boolean")throw new Error(`Provider settings are incomplete: ${c.id}`);if(l.model.length>200||["__proto__","prototype","constructor"].includes(l.model.trim())||(l.enabled||l.capability)&&!l.model.trim())throw new Error(`Provider model is invalid: ${c.id}`);if(!Number.isInteger(l.contextWindowTokens)||l.contextWindowTokens<4096)throw new Error(`Context window is invalid: ${c.id}`);if(!Number.isInteger(l.maxOutputTokens)||l.maxOutputTokens<256)throw new Error(`Output limit is invalid: ${c.id}`);if(l.modelProfiles!==void 0){const L=_(l.modelProfiles);for(const[U,f]of Object.entries(L)){const D=_(f);if(!U.trim()||U.length>200||["__proto__","prototype","constructor"].includes(U))throw new Error(`Saved model name is invalid: ${c.id}`);if(!Number.isInteger(D.contextWindowTokens)||D.contextWindowTokens<4096)throw new Error(`Saved model context window is invalid: ${c.id}`);if(!Number.isInteger(D.maxOutputTokens)||D.maxOutputTokens<256)throw new Error(`Saved model output limit is invalid: ${c.id}`)}}if(l.capability){const L=l.capability,U=L.lookupReady===!0||c.id===H&&L.lookupReady===!1;if(L.conversationReady!==!0||!U||!Number.isInteger(L.contractVersion)||L.contractVersion<1||L.baseUrl.replace(/\/$/,"")!==l.baseUrl.replace(/\/$/,"")||L.model!==l.model||!["json_schema","json_object","prompt_json"].includes(L.outputMode)||typeof L.testedAt!="string")throw new Error(`Provider capability is stale or invalid: ${c.id}`)}if(l.price!==void 0){const L=_(l.price),U=f=>typeof f=="number"&&Number.isFinite(f)&&f>=0&&f<=1e4;if(!U(L.input)||!U(L.output))throw new Error(`Price is invalid: ${c.id}`)}return structuredClone(l)});if(i.defaultProvider&&!u.some(c=>c.id===i.defaultProvider))throw new Error("Default provider is invalid");if(i.reviewProvider&&!u.some(c=>c.id===i.reviewProvider))throw new Error("Review provider is invalid");return structuredClone(e)}function ee(){return N(this,null,function*(){yield ue()})}function p(e,t,r=384){return N(this,null,function*(){yield ee();const n=`${e}.${process.pid}.${_e()}.tmp`;yield me(n,`${JSON.stringify(t,null,2)}
`),yield pe(n,e)})}function B(e){if(!e||typeof e!="object"||Array.isArray(e)||Object.values(e).some(t=>typeof t!="string"))throw new Error("Expected every secret value to be a string");return structuredClone(e)}function te(e){return e instanceof Error&&e.code==="ENOENT"}function ne(e,t,r){return N(this,null,function*(){const n=yield Ue(e).catch(()=>{}),i=new Date(n?.mtimeMs||Date.now()).toISOString().replace(/[:.]/g,"-"),T=`${e}.broken-${i}`;return yield Oe(e,T,fe.COPYFILE_EXCL).catch(E=>{if(E.code!=="EEXIST")throw E}),Object.assign(new Error(`${t} is invalid. The original file was preserved and backed up to ${T}. Run "npm run doctor" for repair instructions.`,{cause:r}),{code:"LOCAL_CONFIG_INVALID",backupPath:T})})}let z,oe=Promise.resolve();function re(e){const t=oe.then(e,e);return oe=t.then(()=>{},()=>{}),t}function ke(){return N(this,null,function*(){let e;try{e=yield V(F,"utf8")}catch(t){if(te(t))return;throw t}try{const t=JSON.parse(e);if(t.version!==1)throw new Error("Unsupported provider transaction version");const r=S(t.config),n=B(t.secrets);yield p(I,r),yield p(h,n),yield se(F)}catch(t){throw yield ne(F,"Pending provider transaction",t)}})}function y(){return z||=ke(),z}function xe(){return N(this,null,function*(){yield ee(),yield y();let e;try{e=yield V(I,"utf8")}catch(n){if(!te(n))throw n;return yield p(I,j),structuredClone(j)}let t,r;try{t=JSON.parse(e),r=S(t)}catch(n){throw yield ne(I,"Local configuration",n)}return r})}function je(e){return N(this,null,function*(){const t=S(e);return yield y(),re(()=>N(null,null,function*(){return yield p(I,t),t}))})}function Me(e,t){return N(this,null,function*(){const r=S(e),n=B(t);return yield y(),re(()=>N(null,null,function*(){yield p(F,{version:1,config:r,secrets:n});try{return yield p(I,r),yield p(h,n),yield se(F),r}catch(i){z=void 0;try{return yield y(),r}catch(T){throw new AggregateError([i,T],"Could not persist the provider configuration transaction.")}}}))})}function at(){return N(this,arguments,function*(e={}){const t=structuredClone(j);return e.clearSecrets?yield Ge(t,{}):yield w(t),t})}function Te(){return N(this,null,function*(){yield ee(),yield y();let e;try{e=yield V(h,"utf8")}catch(t){if(!te(t))throw t;return yield p(h,{}),{}}try{return B(JSON.parse(e))}catch(t){throw yield ne(h,"Local secrets file",t)}})}function Ye(e,t){return N(this,null,function*(){yield y(),yield re(()=>N(null,null,function*(){const r=yield Te();t?r[e]=t:delete r[e],yield p(h,r)}))})}const Ke={config:xe,saveConfig:je,saveConfigAndSecrets:Me,secrets:Te,setSecret:Ye},$=()=>Ke;function X(){return N(this,null,function*(){return $().config()})}function w(e){return N(this,null,function*(){return $().saveConfig(S(e))})}function Ge(e,t){return N(this,null,function*(){return $().saveConfigAndSecrets(S(e),B(t))})}function st(){return N(this,null,function*(){return $().secrets()})}const Ee=K;let P=new Q(R.join(Ee,"app.db")),b,ce=()=>{};function k(){return b??ce()??P}const a={prepare:(...e)=>k().prepare(...e),exec:(...e)=>k().exec(...e),close:()=>k().close()};function Be(){a.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      mode TEXT NOT NULL,
      title TEXT NOT NULL,
      setup_json TEXT,
      interface_locale TEXT NOT NULL DEFAULT '',
      target_language TEXT NOT NULL DEFAULT '',
      target_language_code TEXT NOT NULL DEFAULT '',
      localized_setups_json TEXT NOT NULL DEFAULT '{}',
      state_json TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      archived_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_episodes (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      start_message_id TEXT NOT NULL,
      end_message_id TEXT NOT NULL,
      thread TEXT NOT NULL,
      summary TEXT NOT NULL,
      facts_json TEXT NOT NULL DEFAULT '[]',
      open_loops_json TEXT NOT NULL DEFAULT '[]',
      keywords_json TEXT NOT NULL DEFAULT '[]',
      topic_arcs_json TEXT NOT NULL DEFAULT '[]',
      interaction_signals_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      meta_json TEXT,
      client_message_id TEXT,
      reply_to_message_id TEXT,
      status TEXT NOT NULL DEFAULT 'complete',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS scene_anchors (
      id TEXT PRIMARY KEY,
      preset_id TEXT NOT NULL,
      target_language_code TEXT NOT NULL,
      raw_value TEXT NOT NULL,
      normalized_value TEXT NOT NULL,
      interface_locale TEXT NOT NULL DEFAULT '',
      confirmed_facts_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(preset_id, target_language_code, normalized_value)
    );
    CREATE TABLE IF NOT EXISTS scene_backgrounds (
      id TEXT PRIMARY KEY,
      anchor_id TEXT NOT NULL REFERENCES scene_anchors(id) ON DELETE CASCADE,
      preset_id TEXT NOT NULL,
      target_language_code TEXT NOT NULL,
      identity_key TEXT NOT NULL,
      stable_fingerprint TEXT NOT NULL,
      background_json TEXT NOT NULL,
      saved INTEGER NOT NULL DEFAULT 0,
      use_count INTEGER NOT NULL DEFAULT 0,
      last_used_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(anchor_id, identity_key)
    );
    CREATE TABLE IF NOT EXISTS scene_runs (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL UNIQUE REFERENCES conversations(id) ON DELETE CASCADE,
      anchor_id TEXT NOT NULL REFERENCES scene_anchors(id) ON DELETE CASCADE,
      background_id TEXT REFERENCES scene_backgrounds(id) ON DELETE SET NULL,
      preset_id TEXT NOT NULL,
      target_language_code TEXT NOT NULL,
      run_mode TEXT NOT NULL DEFAULT 'new_encounter',
      dynamic_fingerprint TEXT NOT NULL,
      opening_fingerprint TEXT NOT NULL,
      encounter_json TEXT NOT NULL,
      opening_line TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS word_entries (
      id TEXT PRIMARY KEY,
      term TEXT NOT NULL,
      lemma TEXT NOT NULL,
      language TEXT NOT NULL,
      interface_locale TEXT NOT NULL DEFAULT '',
      meaning TEXT NOT NULL,
      details_json TEXT NOT NULL,
      source_sentence TEXT,
      conversation_id TEXT,
      due_at TEXT NOT NULL,
      interval_days INTEGER NOT NULL DEFAULT 0,
      ease REAL NOT NULL DEFAULT 2.3,
      repetitions INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS memories (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL,
      key TEXT NOT NULL,
      semantic_slot TEXT NOT NULL DEFAULT '',
      value TEXT NOT NULL,
      interface_locale TEXT NOT NULL DEFAULT '',
      localized_values_json TEXT NOT NULL DEFAULT '{}',
      tier TEXT NOT NULL DEFAULT 'long_term',
      memory_type TEXT NOT NULL DEFAULT 'preference',
      topic TEXT NOT NULL DEFAULT 'general',
      importance REAL NOT NULL DEFAULT 0.5,
      pinned INTEGER NOT NULL DEFAULT 0,
      confidence REAL NOT NULL DEFAULT 1,
      sensitive INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'confirmed',
      source_conversation_id TEXT,
      source_message_id TEXT,
      supersedes_id TEXT,
      valid_from TEXT,
      valid_to TEXT,
      last_used_at TEXT,
      use_count INTEGER NOT NULL DEFAULT 0,
      last_mentioned_at TEXT,
      mention_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(category, key)
    );
    CREATE TABLE IF NOT EXISTS memory_revisions (
      id TEXT PRIMARY KEY,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      previous_value TEXT,
      next_value TEXT,
      change_type TEXT NOT NULL,
      source_conversation_id TEXT,
      source_message_id TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS memory_sources (
      id TEXT PRIMARY KEY,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      conversation_id TEXT,
      message_id TEXT,
      frame TEXT NOT NULL DEFAULT '',
      scene_title TEXT NOT NULL DEFAULT '',
      quote TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_memories (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      key TEXT NOT NULL,
      semantic_slot TEXT NOT NULL,
      value TEXT NOT NULL,
      quote TEXT NOT NULL DEFAULT '',
      about TEXT NOT NULL DEFAULT 'persona',
      durability TEXT NOT NULL DEFAULT 'momentary',
      memory_type TEXT NOT NULL DEFAULT 'preference',
      topic TEXT NOT NULL DEFAULT 'general',
      sensitive INTEGER NOT NULL DEFAULT 0,
      interface_locale TEXT NOT NULL DEFAULT '',
      source_message_id TEXT,
      promoted_memory_id TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(conversation_id, semantic_slot)
    );
    CREATE TABLE IF NOT EXISTS learning_events (
      id TEXT PRIMARY KEY,
      target_language_code TEXT NOT NULL,
      kind TEXT NOT NULL,
      category TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT '',
      original TEXT NOT NULL,
      improved TEXT NOT NULL,
      conversation_id TEXT,
      message_id TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS memory_suggestions (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      memory_id TEXT,
      conversation_memory_id TEXT,
      conversation_id TEXT,
      value TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      payload_json TEXT NOT NULL DEFAULT '{}',
      interface_locale TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL,
      resolved_at TEXT
    );
    CREATE TABLE IF NOT EXISTS app_flags (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS translation_cache (
      cache_key TEXT PRIMARY KEY,
      translation TEXT NOT NULL,
      hit_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      last_accessed TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ai_response_cache (
      cache_type TEXT NOT NULL,
      cache_key TEXT NOT NULL,
      response_json TEXT NOT NULL,
      hit_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      last_accessed TEXT NOT NULL,
      PRIMARY KEY (cache_type, cache_key)
    );
    CREATE TABLE IF NOT EXISTS web_lookup_cache (
      cache_key TEXT PRIMARY KEY,
      query TEXT NOT NULL,
      result_json TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_accessed TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS proficiency_profiles (
      language_code TEXT PRIMARY KEY,
      score REAL NOT NULL,
      working_step INTEGER NOT NULL,
      confidence TEXT NOT NULL DEFAULT 'low',
      skills_json TEXT NOT NULL DEFAULT '{}',
      source TEXT NOT NULL DEFAULT 'self',
      locked INTEGER NOT NULL DEFAULT 0,
      tested_at TEXT,
      tested_step INTEGER,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS proficiency_history (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      kind TEXT NOT NULL,
      from_step INTEGER,
      to_step INTEGER NOT NULL,
      reason TEXT NOT NULL,
      evidence_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS placement_sessions (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      language_name TEXT NOT NULL DEFAULT '',
      interface_locale TEXT NOT NULL DEFAULT '',
      mode TEXT NOT NULL DEFAULT 'full',
      status TEXT NOT NULL DEFAULT 'active',
      state_json TEXT NOT NULL DEFAULT '{}',
      result_json TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS placement_items (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      level TEXT NOT NULL,
      kind TEXT NOT NULL,
      item_json TEXT NOT NULL,
      use_count INTEGER NOT NULL DEFAULT 0,
      last_used_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS turn_signals (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      partner_message_id TEXT NOT NULL,
      user_message_id TEXT,
      language_code TEXT NOT NULL DEFAULT '',
      step INTEGER NOT NULL DEFAULT 0,
      length INTEGER NOT NULL DEFAULT 0,
      meaning_errors INTEGER NOT NULL DEFAULT 0,
      naturalness_errors INTEGER NOT NULL DEFAULT 0,
      non_target INTEGER NOT NULL DEFAULT 0,
      lookups INTEGER NOT NULL DEFAULT 0,
      translated INTEGER NOT NULL DEFAULT 0,
      simpler INTEGER NOT NULL DEFAULT 0,
      slower INTEGER NOT NULL DEFAULT 0,
      hints INTEGER NOT NULL DEFAULT 0,
      heard INTEGER NOT NULL DEFAULT 0,
      revealed INTEGER NOT NULL DEFAULT 0,
      lowered INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(conversation_id, partner_message_id)
    );
    CREATE TABLE IF NOT EXISTS conversation_assessments (
      conversation_id TEXT PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
      language_code TEXT NOT NULL,
      base_step INTEGER NOT NULL,
      estimate_step INTEGER NOT NULL,
      valid INTEGER NOT NULL DEFAULT 0,
      verdict TEXT NOT NULL DEFAULT 'fit',
      stats_json TEXT NOT NULL DEFAULT '{}',
      expression_step REAL,
      last_message_id TEXT,
      assessed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_recaps (
      conversation_id TEXT PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      last_message_id TEXT,
      content_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS practice_sets (
      id TEXT PRIMARY KEY,
      conversation_id TEXT REFERENCES conversations(id) ON DELETE CASCADE,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      items_json TEXT NOT NULL,
      answers_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS word_reviews (
      id TEXT PRIMARY KEY,
      word_id TEXT NOT NULL,
      language TEXT NOT NULL,
      rating INTEGER NOT NULL,
      source TEXT NOT NULL,
      conversation_id TEXT,
      state_before INTEGER NOT NULL DEFAULT 0,
      scheduled_days INTEGER NOT NULL DEFAULT 0,
      reviewed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_words (
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      word_id TEXT NOT NULL,
      term TEXT NOT NULL,
      meaning TEXT NOT NULL,
      source TEXT NOT NULL,
      arranged_at TEXT NOT NULL,
      used_at TEXT,
      result TEXT,
      message_id TEXT,
      PRIMARY KEY (conversation_id, word_id)
    );
    CREATE TABLE IF NOT EXISTS word_stories (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      step INTEGER NOT NULL,
      title TEXT NOT NULL,
      content_json TEXT NOT NULL,
      conversation_id TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS content_imports (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      step INTEGER NOT NULL,
      source_kind TEXT NOT NULL,
      source_url TEXT,
      source_title TEXT NOT NULL DEFAULT '',
      title TEXT NOT NULL,
      content_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS learning_paths (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      items_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `)}function d(e,t,r){new Set(a.prepare(`PRAGMA table_info(${e})`).all().map(i=>i.name)).has(t)||a.exec(`ALTER TABLE ${e} ADD COLUMN ${t} ${r}`)}function $e(){d("turn_signals","heard","INTEGER NOT NULL DEFAULT 0"),d("turn_signals","revealed","INTEGER NOT NULL DEFAULT 0"),d("conversations","interface_locale","TEXT NOT NULL DEFAULT ''"),d("conversations","localized_setups_json","TEXT NOT NULL DEFAULT '{}'"),d("conversations","target_language","TEXT NOT NULL DEFAULT ''"),d("conversations","target_language_code","TEXT NOT NULL DEFAULT ''"),d("conversation_episodes","topic_arcs_json","TEXT NOT NULL DEFAULT '[]'"),d("conversation_episodes","interaction_signals_json","TEXT NOT NULL DEFAULT '[]'"),d("word_entries","interface_locale","TEXT NOT NULL DEFAULT ''"),d("word_entries","fsrs_json","TEXT NOT NULL DEFAULT ''"),d("conversations","material_json","TEXT NOT NULL DEFAULT ''"),d("memories","interface_locale","TEXT NOT NULL DEFAULT ''"),d("memories","localized_values_json","TEXT NOT NULL DEFAULT '{}'"),d("memories","semantic_slot","TEXT NOT NULL DEFAULT ''"),d("memories","tier","TEXT NOT NULL DEFAULT 'long_term'"),d("memories","memory_type","TEXT NOT NULL DEFAULT 'preference'"),d("memories","topic","TEXT NOT NULL DEFAULT 'general'"),d("memories","importance","REAL NOT NULL DEFAULT 0.5"),d("memories","pinned","INTEGER NOT NULL DEFAULT 0"),d("memories","source_message_id","TEXT"),d("memories","supersedes_id","TEXT"),d("memories","valid_from","TEXT"),d("memories","valid_to","TEXT"),d("memories","last_used_at","TEXT"),d("memories","use_count","INTEGER NOT NULL DEFAULT 0"),d("memories","last_mentioned_at","TEXT"),d("memories","mention_count","INTEGER NOT NULL DEFAULT 0"),d("memories","target_language_code","TEXT NOT NULL DEFAULT ''"),d("conversations","consolidated_message_id","TEXT"),d("conversations","difficulty_json","TEXT"),a.exec(`
    UPDATE memories SET valid_from = created_at WHERE valid_from IS NULL;
    UPDATE memories SET memory_type = 'learning' WHERE category = 'learning' AND memory_type = 'preference';
  `),a.exec(`
    UPDATE OR IGNORE memories SET memory_type = 'plan', category = 'plan' WHERE category = 'scene' OR memory_type = 'episodic';
    UPDATE OR IGNORE memories SET category = 'about' WHERE category = 'personal';
  `)}function de(){if(a.prepare("SELECT 1 FROM app_flags WHERE key = 'memory_scope_review'").get())return;const e=new Date().toISOString(),t=a.prepare(`SELECT m.id AS id, m.source_conversation_id AS conversationId, m.source_message_id AS messageId,
    m.created_at AS createdAt, COALESCE(NULLIF(CASE WHEN json_valid(c.setup_json) THEN json_extract(c.setup_json, '$.title') END, ''), c.title) AS title, c.setup_json AS setupJson
    FROM memories m JOIN conversations c ON c.id = m.source_conversation_id
    WHERE NOT EXISTS (SELECT 1 FROM memory_sources s WHERE s.memory_id = m.id)`).all();a.exec("BEGIN IMMEDIATE");try{let r=0;for(const n of t){const i=!!(n.setupJson&&n.setupJson.trim()&&n.setupJson.trim()!=="null");r+=1,a.prepare(`INSERT INTO memory_sources (id, memory_id, conversation_id, message_id, frame, scene_title, quote, created_at)
        VALUES (?, ?, ?, ?, ?, ?, '', ?)`).run(`source-${n.id}-${r}`,n.id,n.conversationId,n.messageId,i?"scene":"direct",i&&n.title||"",n.createdAt||e),i&&a.prepare(`INSERT INTO memory_suggestions (id, kind, memory_id, conversation_id, status, created_at)
        VALUES (?, 'review', ?, ?, 'open', ?)`).run(`review-${n.id}`,n.id,n.conversationId,e)}a.prepare("INSERT INTO app_flags (key, value) VALUES ('memory_scope_review', ?)").run(e),a.exec("COMMIT")}catch(r){throw a.exec("ROLLBACK"),r}}function We(){a.exec("CREATE UNIQUE INDEX IF NOT EXISTS messages_client_id_unique ON messages(conversation_id, client_message_id) WHERE client_message_id IS NOT NULL"),a.exec("CREATE UNIQUE INDEX IF NOT EXISTS messages_reply_to_unique ON messages(reply_to_message_id) WHERE reply_to_message_id IS NOT NULL"),a.exec("CREATE INDEX IF NOT EXISTS translation_cache_accessed_index ON translation_cache(last_accessed DESC)"),a.exec("CREATE INDEX IF NOT EXISTS ai_response_cache_accessed_index ON ai_response_cache(cache_type, last_accessed DESC)"),a.exec("CREATE INDEX IF NOT EXISTS conversation_episodes_conversation_index ON conversation_episodes(conversation_id, created_at)"),a.exec("CREATE INDEX IF NOT EXISTS scene_anchors_lookup_index ON scene_anchors(preset_id, target_language_code, normalized_value)"),a.exec("CREATE INDEX IF NOT EXISTS scene_backgrounds_anchor_index ON scene_backgrounds(anchor_id, use_count, last_used_at)"),a.exec("CREATE INDEX IF NOT EXISTS scene_runs_anchor_index ON scene_runs(anchor_id, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS scene_runs_preset_index ON scene_runs(preset_id, target_language_code, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS web_lookup_cache_expiry_index ON web_lookup_cache(expires_at)"),a.exec("DROP INDEX IF EXISTS memories_retrieval_index"),a.exec("CREATE INDEX memories_retrieval_index ON memories(status, tier, topic, updated_at DESC)"),a.exec("CREATE UNIQUE INDEX IF NOT EXISTS memories_semantic_slot_unique ON memories(semantic_slot) WHERE semantic_slot <> ''"),a.exec("CREATE INDEX IF NOT EXISTS memory_revisions_memory_index ON memory_revisions(memory_id, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS memory_sources_memory_index ON memory_sources(memory_id, created_at)"),a.exec("CREATE INDEX IF NOT EXISTS conversation_memories_conversation_index ON conversation_memories(conversation_id, updated_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS learning_events_language_index ON learning_events(target_language_code, kind, category, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS memory_suggestions_status_index ON memory_suggestions(status, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS proficiency_history_language_index ON proficiency_history(language_code, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS placement_items_lookup_index ON placement_items(language_code, interface_locale, level, kind, use_count)"),a.exec("CREATE INDEX IF NOT EXISTS turn_signals_conversation_index ON turn_signals(conversation_id, created_at)"),a.exec("CREATE INDEX IF NOT EXISTS conversation_assessments_language_index ON conversation_assessments(language_code, assessed_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS practice_sets_conversation_index ON practice_sets(conversation_id, created_at DESC)"),a.exec("CREATE INDEX IF NOT EXISTS word_entries_due_index ON word_entries(due_at)"),a.exec("CREATE INDEX IF NOT EXISTS word_reviews_time_index ON word_reviews(reviewed_at)"),a.exec("CREATE INDEX IF NOT EXISTS content_imports_time_index ON content_imports(created_at DESC)")}function le(){Be(),$e(),de(),We()}le();function Ne(e="app.db"){return R.join(Ee,e)}function Le(e){const t=b;b=e;try{le()}finally{b=t}}function M(e){P.close(),P=new Q(e),Le(P)}function Je(e){const t=new Q(e);return Le(t),t}function He(e){ce=e}function ze(e){const t=new WeakMap;return()=>{const r=k();let n=t.get(r);return n||t.set(r,n=e()),n}}function Ve(e,...t){return a.prepare(e).all(...t)}function Qe(e,...t){return a.prepare(e).get(...t)}var Tt=Object.freeze({__proto__:null,chooseDatabaseWith:He,databaseFile:Ne,db:a,openDatabase:Je,perDatabase:ze,reviewMemoriesFromScenes:de,row:Qe,rows:Ve,useDatabase:M}),A=(e,t,r)=>new Promise((n,i)=>{var T=o=>{try{s(r.next(o))}catch(u){i(u)}},E=o=>{try{s(r.throw(o))}catch(u){i(u)}},s=o=>o.done?n(o.value):Promise.resolve(o.value).then(T,E);s((r=r.apply(e,t)).next())});const ie=Ie("abcdefghijklmnopqrstuvwxyz0123456789",10),qe=40;let Y=G;function Ze(){return Y}function x(e){return Ne(e===G?"app.db":`profile-${e}.db`)}function v(e){return e.profiles?.length?e.profiles:[{id:G,name:"",createdAt:""}]}function O(e){const t=v(e);return t.find(r=>r.id===e.activeProfile)?.id||t[0].id}function et(){return A(this,null,function*(){const e=O(yield X());e!==Y&&(M(x(e)),Y=e)})}function g(e){const t=O(e);return{max:Z,profiles:v(e).map(r=>({id:r.id,name:r.name,createdAt:r.createdAt,active:r.id===t,targetLanguageCode:r.id===t?e.learning.targetLanguageCode:r.learning?.targetLanguageCode||""}))}}function m(e,t,r){return Object.assign(new Error(e),{statusCode:t,code:r})}function ae(e){const t=typeof e=="string"?e.trim().replace(/\s+/gu," "):"";if(!t||t.length>qe)throw m("A profile needs a name of at most 40 characters.",400,"PROFILE_NAME_INVALID");return t}function W(e){const{difficultyStep:t,...r}=e;return r}function tt(e,t){e.get("/api/profiles",()=>A(null,null,function*(){return g(yield X())})),e.post("/api/profiles",r=>A(null,null,function*(){const n=yield X(),i=v(n);if(i.length>=Z)throw m("No more profiles can be added.",409,"PROFILE_LIMIT");const T=ae(r.body?.name);if(i.some(c=>c.name.toLowerCase()===T.toLowerCase()))throw m("A profile with this name exists.",409,"PROFILE_NAME_TAKEN");const E=J.some(c=>c.code===r.body?.targetLanguageCode)?String(r.body.targetLanguageCode):n.learning.targetLanguageCode;let s=ie();for(;i.some(c=>c.id===s);)s=ie();const o={id:s,name:T,createdAt:new Date().toISOString(),learning:{...j.learning,targetLanguage:Re(E).name,targetLanguageCode:E},uiLocale:n.ui.locale},u=yield w({...n,profiles:[...i,o],activeProfile:O(n)});return{id:s,...g(u)}})),e.patch("/api/profiles/:id",r=>A(null,null,function*(){const n=yield X(),i=v(n);if(!i.some(s=>s.id===r.params.id))throw m("Profile not found",404,"PROFILE_NOT_FOUND");const T=ae(r.body?.name);if(i.some(s=>s.id!==r.params.id&&s.name.toLowerCase()===T.toLowerCase()))throw m("A profile with this name exists.",409,"PROFILE_NAME_TAKEN");const E=yield w({...n,profiles:i.map(s=>s.id===r.params.id?{...s,name:T}:s),activeProfile:O(n)});return g(E)})),e.post("/api/profiles/:id/activate",r=>A(null,null,function*(){const n=yield X(),i=v(n),T=O(n),E=i.find(o=>o.id===r.params.id);if(!E)throw m("Profile not found",404,"PROFILE_NOT_FOUND");if(E.id===T)return g(n);if(t.busy())throw m("A reply is still being written. Switch once it has arrived.",409,"PROFILE_BUSY");const s={...n,profiles:i.map(o=>o.id===T?{...o,learning:W(n.learning),uiLocale:n.ui.locale}:o.id===E.id?{id:o.id,name:o.name,createdAt:o.createdAt}:o),activeProfile:E.id,learning:E.learning?W(E.learning):W(n.learning),ui:{...n.ui,locale:E.uiLocale||n.ui.locale}};M(x(E.id));try{const o=yield w(s);return Y=E.id,g(o)}catch(o){throw M(x(T)),o}})),e.delete("/api/profiles/:id",r=>A(null,null,function*(){const n=yield X(),i=v(n),T=i.find(o=>o.id===r.params.id);if(!T)throw m("Profile not found",404,"PROFILE_NOT_FOUND");if(T.id===O(n))throw m("The profile in use cannot be deleted. Switch to another first.",409,"PROFILE_IN_USE");const E=yield w({...n,profiles:i.filter(o=>o.id!==T.id),activeProfile:O(n)}),s=x(T.id);return yield Promise.all([s,`${s}-wal`,`${s}-shm`].map(o=>ge(o,{force:!0}))),g(E)}))}var Et=Object.freeze({__proto__:null,activeProfileId:Ze,openActiveProfile:et,registerProfileRoutes:tt});export{H as C,J as T,Ee as a,st as b,Ve as c,a as d,rt as e,Ze as f,X as g,Ge as h,tt as i,at as j,Ce as k,ot as l,it as m,ye as n,et as o,ze as p,Tt as q,Qe as r,w as s,Re as t,Et as u};
