import{_ as m}from"./SceneGlyph.vue_vue_type_script_setup_true_lang-Dee2LqU3.js";import"./index-N7fTgw_g.js";export{m as default};
