const _=3,s="___";export{s as P,_ as R};
