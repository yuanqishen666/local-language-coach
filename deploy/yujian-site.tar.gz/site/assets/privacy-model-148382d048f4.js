const line = document.querySelector('[data-privacy-model]')
fetch(line.dataset.privacyModel, { credentials: 'omit' })
  .then((response) => response.ok ? response.json() : undefined)
  .then((model) => {
    if (typeof model?.name !== 'string' || !model.name) return
    line.textContent = line.dataset.modelText.replace('{model}', () => model.name)
    line.hidden = false
  }).catch(() => {})