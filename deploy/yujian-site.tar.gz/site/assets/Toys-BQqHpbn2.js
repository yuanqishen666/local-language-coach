import{_ as o}from"./Toys.vue_vue_type_script_setup_true_lang-ltaCm9_Q.js";import"./interactions-D0FZ_Neh.js";import"./index-N7fTgw_g.js";export{o as default};
