import{_ as o}from"./Face.vue_vue_type_style_index_0_lang-Czgmccv_.js";import"./interactions-D0FZ_Neh.js";import"./index-N7fTgw_g.js";export{o as default};
