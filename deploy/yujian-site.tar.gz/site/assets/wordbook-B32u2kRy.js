const s=3,I=80;export{I,s as S};
