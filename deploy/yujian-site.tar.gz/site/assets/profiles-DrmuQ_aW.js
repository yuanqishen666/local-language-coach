import{s as U,B as ie,i as fe,r as De,a as Ce,o as be,l as Pe,c as ke}from"./worker-CZ8NdSoU.js";let xe="useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict",je=e=>crypto.getRandomValues(new Uint8Array(e)),Me=(e,t,r)=>{let n=256-256%e.length;if(n===256){let s=e.length-1;return(T=t)=>{if(!T)return"";let a="";for(;;){let i=r(T),N=T;for(;N--;)if(a+=e[i[N]&s],a.length>=T)return a}}}let o=Math.ceil(1.6*256*t/n);return(s=t)=>{if(!s)return"";let T="";for(;;){let a=r(o),i=o;for(;i--;)if(a[i]<n&&(T+=e[a[i]%e.length],T.length>=s))return T}}},Ye=(e,t=21)=>Me(e,t|0,je),wt=(e=21)=>{let t="",r=crypto.getRandomValues(new Uint8Array(e|=0));for(;e--;)t+=xe[r[e]&63];return t};var p=(e,t,r)=>new Promise((n,o)=>{var s=i=>{try{a(r.next(i))}catch(N){o(N)}},T=i=>{try{a(r.throw(i))}catch(N){o(N)}},a=i=>i.done?n(i.value):Promise.resolve(i.value).then(s,T);a((r=r.apply(e,t)).next())});function A(e,t){return Object.assign(new Error(`${e}: ${e==="ENOENT"?"no such file or directory":"file already exists"}, '${t}'`),{code:e,path:t})}function se(e,t){const r=U.read(e);if(!r)throw A("ENOENT",e);return(typeof t=="string"?t:t?.encoding)?new TextDecoder().decode(r):ie.from(r)}const pe=e=>typeof e=="string"?new TextEncoder().encode(e):e,Ue={COPYFILE_EXCL:1};function ae(e,t){return p(this,null,function*(){return se(e,t)})}function Ke(e,t,r){return p(this,null,function*(){U.write(e,pe(t))})}function Ge(e,t){return p(this,null,function*(){if(!U.move(e,t))throw A("ENOENT",e)})}function Be(e,t,r=0){return p(this,null,function*(){const n=se(e);if(r&Ue.COPYFILE_EXCL&&U.modified(t)!==void 0)throw A("EEXIST",t);U.write(t,n)})}function Oe(e){return p(this,null,function*(){if(!U.remove(e))throw A("ENOENT",e)})}function $e(e){return p(this,arguments,function*(t,r={}){if(!U.remove(t)&&!Ce(t)&&!r.force)throw A("ENOENT",t)})}function We(e){return p(this,null,function*(){const t=U.modified(e);if(t===void 0)throw A("ENOENT",e);return{mtimeMs:t}})}function St(e,t="r",r){return p(this,null,function*(){const n=U.modified(e)!==void 0;if(t.includes("x")&&n)throw A("EEXIST",e);if(t.includes("w"))U.write(e,new Uint8Array);else if(!n)throw A("ENOENT",e);return{writeFile:o=>p(null,null,function*(){return U.write(e,pe(o))}),sync:()=>p(null,null,function*(){}),close:()=>p(null,null,function*(){})}})}function He(e,t){return p(this,null,function*(){})}function Ft(e){return fe(e)||U.modified(e)!==void 0}function Dt(e,t){return fe(e)?De(e):se(e,t)}const ze=Uint32Array.of(1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298),g=(e,t)=>e>>>t|e<<32-t;function M(e){const t=Uint32Array.of(1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225),r=new Uint8Array(e.length+9+63>>6<<6);r.set(e),r[e.length]=128;const n=new DataView(r.buffer);n.setUint32(r.length-8,Math.floor(e.length/536870912)),n.setUint32(r.length-4,e.length<<3>>>0);const o=new Uint32Array(64);for(let a=0;a<r.length;a+=64){for(let u=0;u<16;u+=1)o[u]=n.getUint32(a+u*4);for(let u=16;u<64;u+=1){const j=g(o[u-15],7)^g(o[u-15],18)^o[u-15]>>>3,Z=g(o[u-2],17)^g(o[u-2],19)^o[u-2]>>>10;o[u]=o[u-16]+j+o[u-7]+Z}let[i,N,E,l,L,f,O,v]=t;for(let u=0;u<64;u+=1){const j=v+(g(L,6)^g(L,11)^g(L,25))+(L&f^~L&O)+ze[u]+o[u]|0,Z=(g(i,2)^g(i,13)^g(i,22))+(i&N^i&E^N&E)|0;v=O,O=f,f=L,L=l+j|0,l=E,E=N,N=i,i=j+Z|0}t[0]+=i,t[1]+=N,t[2]+=E,t[3]+=l,t[4]+=L,t[5]+=f,t[6]+=O,t[7]+=v}const s=new Uint8Array(32),T=new DataView(s.buffer);return t.forEach((a,i)=>T.setUint32(i*4,a)),s}function te(e){const t=new Uint8Array(e.reduce((n,o)=>n+o.length,0));let r=0;for(const n of e)t.set(n,r),r+=n.length;return t}const ge=e=>typeof e=="string"?new TextEncoder().encode(e):e;function he(e){if(e.toLowerCase()!=="sha256")throw new Error(`Digest method not supported: ${e}`)}function Xe(e){const t=[],r={update(n){return t.push(ge(n)),r},digest(n){const o=ie.from(e(te(t)));return n?o.toString(n):o}};return r}function Ct(e){return he(e),Xe(M)}function bt(e,t){he(e);const r=ge(t),n=new Uint8Array(64);n.set(r.length>64?M(r):r);const o=n.map(T=>T^54),s=n.map(T=>T^92);return Xe(T=>M(te([s,M(te([o,T]))])))}function Je(){return crypto.randomUUID()}function Pt(e){return ie.from(crypto.getRandomValues(new Uint8Array(e)))}function kt(e,t){const n=e-0;if(!Number.isSafeInteger(n)||n<=0||n>4294967296)throw new RangeError("The range must be between 1 and 2 ** 32 wide");const o=4294967296-4294967296%n,s=new Uint32Array(1);do crypto.getRandomValues(s);while(s[0]>=o);return 0+s[0]%n}function xt(e,t){if(e.length!==t.length)throw new RangeError("Input buffers must have the same byte length");let r=0;for(let n=0;n<e.length;n+=1)r|=e[n]^t[n];return r===0}function ve(e){const t=[];for(const r of e.join("/").split("/"))!r||r==="."||(r===".."?t.pop():t.push(r));return t.join("/")}function Ve(...e){const t=ve(e);return e.find(Boolean)?.startsWith("/")?`/${t}`:t||"."}function Qe(...e){const t=e.findLastIndex(r=>r.startsWith("/"));return`/${ve(t<0?e:e.slice(t))}`}const qe="/";var b={join:Ve,resolve:Qe,sep:qe};const Te=["zh-CN","en-US","es-419","fr-FR","ja-JP","de-DE","ko-KR","it-IT","pt-BR","hi-IN"],ne=[{code:"en",name:"English",locale:"en-US"},{code:"es",name:"Spanish",locale:"es-419"},{code:"fr",name:"French",locale:"fr-FR"},{code:"ja",name:"Japanese",locale:"ja-JP"},{code:"de",name:"German",locale:"de-DE"},{code:"ko",name:"Korean",locale:"ko-KR"},{code:"it",name:"Italian",locale:"it-IT"},{code:"zh",name:"Chinese",locale:"zh-CN"},{code:"pt",name:"Portuguese",locale:"pt-BR"},{code:"hi",name:"Hindi",locale:"hi-IN"}],Ze={"zh-CN":{code:"zh-CN",shortCode:"中",nativeName:"简体中文",htmlLang:"zh-CN",promptName:"Simplified Chinese as used in mainland China",voice:"Use contemporary, warm, direct Simplified Chinese. Address the user as “你”. Avoid translated sentence patterns, formal notices, and unnecessary linking phrases."},"en-US":{code:"en-US",shortCode:"EN",nativeName:"English",htmlLang:"en-US",promptName:"American English",voice:"Use concise, contemporary American English. Sound helpful and human, not promotional or bureaucratic."},"es-419":{code:"es-419",shortCode:"ES",nativeName:"Español",htmlLang:"es-419",promptName:"neutral Latin American Spanish",voice:"Use natural, widely understood Latin American Spanish. Address the user with “tú”. Avoid literal translations, stiff connectors, and Spain-only wording."},"fr-FR":{code:"fr-FR",shortCode:"FR",nativeName:"Français",htmlLang:"fr-FR",promptName:"French as used in France",voice:"Use natural contemporary French from France. Address the user with “vous”; keep the tone warm, clear, and restrained rather than formal or promotional."},"ja-JP":{code:"ja-JP",shortCode:"日",nativeName:"日本語",htmlLang:"ja-JP",promptName:"Japanese as used in Japan",voice:"Use natural modern Japanese in a friendly です・ます style. Prefer concise product language and avoid calques, excessive subjects, and ceremonial politeness."},"de-DE":{code:"de-DE",shortCode:"DE",nativeName:"Deutsch",htmlLang:"de-DE",promptName:"German as used in Germany",voice:"Use natural contemporary German from Germany. Address the user with “du”. Keep sentences direct and avoid nominal style, anglicized syntax, and bureaucratic wording."},"ko-KR":{code:"ko-KR",shortCode:"한",nativeName:"한국어",htmlLang:"ko-KR",promptName:"Korean as used in South Korea",voice:"Use natural contemporary Korean in a friendly 해요체. Keep interface wording concise and avoid translated word order, excessive nouns, and formal administrative language."},"it-IT":{code:"it-IT",shortCode:"IT",nativeName:"Italiano",htmlLang:"it-IT",promptName:"Italian as used in Italy",voice:"Use natural contemporary Italian from Italy. Address the user with “tu”; keep it clear, warm, and conversational without filler or literal translation patterns."},"pt-BR":{code:"pt-BR",shortCode:"PT",nativeName:"Português",htmlLang:"pt-BR",promptName:"Brazilian Portuguese",voice:"Use natural contemporary Brazilian Portuguese. Address the user with “você”. Prefer everyday phrasing and avoid European Portuguese forms, literal syntax, and stiff connectors."},"hi-IN":{code:"hi-IN",shortCode:"हि",nativeName:"हिन्दी",htmlLang:"hi-IN",promptName:"standard contemporary Hindi as used in India",voice:"Use natural contemporary Hindi in Devanagari. Address the user respectfully with “आप”. Prefer familiar product wording and avoid word-for-word English syntax or overly Sanskritized prose."}};function et(e,t="zh-CN"){return typeof e!="string"?t:Te.includes(e)?e:t}function tt(e){return ne.find(t=>t.code===e)||ne[0]}function jt(e){return Ze[et(e)]}const nt=.85,rt=.6,ot=1.2;var it={},_=(e,t,r)=>new Promise((n,o)=>{var s=i=>{try{a(r.next(i))}catch(N){o(N)}},T=i=>{try{a(r.throw(i))}catch(N){o(N)}},a=i=>i.done?n(i.value):Promise.resolve(i.value).then(s,T);a((r=r.apply(e,t)).next())});const J=it.LLC_DATA_DIR||b.resolve(process.cwd(),"data"),F=b.join(J,"config.json"),D=b.join(J,"secrets.json"),x=b.join(J,"provider-save.transaction.json"),Y=[{id:"openai",name:"OpenAI",kind:"openai",baseUrl:"https://api.openai.com/v1",model:"",apiKeySecret:"providers.openai.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"anthropic",name:"Anthropic",kind:"anthropic",baseUrl:"https://api.anthropic.com/v1",model:"",apiKeySecret:"providers.anthropic.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"gemini",name:"Google Gemini",kind:"gemini",baseUrl:"https://generativelanguage.googleapis.com/v1beta",model:"",apiKeySecret:"providers.gemini.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"deepseek",name:"DeepSeek",kind:"deepseek",baseUrl:"https://api.deepseek.com",model:"",apiKeySecret:"providers.deepseek.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}},{id:"kimi",name:"Moonshot / Kimi",kind:"kimi",baseUrl:"https://api.moonshot.ai/v1",model:"",apiKeySecret:"providers.kimi.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}}],re="custom",V="default",ce=12;function Mt(e,t){return{id:re,name:e,kind:"openai",baseUrl:t,model:"",apiKeySecret:"providers.custom.apiKey",enabled:!1,contextWindowTokens:32768,maxOutputTokens:1200,modelProfiles:{}}}function st(e){if(typeof e!="string"||!e||e.length>300)return!1;try{const t=new URL(e);return(t.protocol==="http:"||t.protocol==="https:")&&!t.username&&!t.password}catch{return!1}}function at(e){return e.kind==="openai"&&e.apiKeySecret==="providers.custom.apiKey"&&typeof e.name=="string"&&e.name.trim().length>0&&e.name.length<=60&&st(e.baseUrl)}function Tt(e){if(e.profiles===void 0){if(e.activeProfile!==void 0&&e.activeProfile!==V)throw new Error("The active profile is invalid");return}if(!Array.isArray(e.profiles)||!e.profiles.length||e.profiles.length>ce)throw new Error("The profile list is invalid");const t=new Set;for(const r of e.profiles){const n=m(r);if(typeof n.id!="string"||!/^[a-z0-9]{1,24}$/u.test(n.id)||t.has(n.id))throw new Error("A profile id is invalid");if(typeof n.name!="string"||n.name.length>40||typeof n.createdAt!="string")throw new Error("A profile is incomplete");if(n.uiLocale!==void 0&&!Te.includes(n.uiLocale))throw new Error("A profile language is invalid");n.learning!==void 0&&m(n.learning),t.add(n.id)}if(e.activeProfile!==void 0&&!t.has(e.activeProfile))throw new Error("The active profile is invalid")}const W={setupComplete:!1,ui:{locale:"zh-CN"},learning:{targetLanguage:"English",targetLanguageCode:"en",proficiency:"B1",correctionLevel:"balanced",speechRate:nt,reviewInConversation:!0},llm:{defaultProvider:"",temperature:.7},webLookup:{enabled:!1,provider:"selected",timeoutMs:8e3,maxResults:5},server:{host:"127.0.0.1",port:4174},providers:Y};function m(e){if(!e||typeof e!="object"||Array.isArray(e))throw new Error("Expected an object");return e}function P(e){const t=m(e),r=m(t.ui),n=m(t.learning),o=m(t.llm),s=m(t.webLookup),T=m(t.server);if(typeof t.setupComplete!="boolean")throw new Error("setupComplete must be boolean");if(!Te.includes(r.locale))throw new Error("Unsupported interface locale");if(typeof n.targetLanguage!="string"||typeof n.targetLanguageCode!="string"||typeof n.proficiency!="string")throw new Error("Learning preferences are incomplete");if(!["light","balanced","intensive"].includes(n.correctionLevel))throw new Error("Unsupported correction level");if(n.speechRate!==void 0&&(typeof n.speechRate!="number"||!Number.isFinite(n.speechRate)||n.speechRate<rt||n.speechRate>ot))throw new Error("Speech rate is invalid");if(n.reviewInConversation!==void 0&&typeof n.reviewInConversation!="boolean")throw new Error("Review setting is invalid");if(n.voiceInput!==void 0&&n.voiceInput!=="browser"&&n.voiceInput!=="model")throw new Error("Voice input setting is invalid");if(n.listenFirst!==void 0&&typeof n.listenFirst!="boolean")throw new Error("Listening setting is invalid");if(n.variant!==void 0&&(typeof n.variant!="string"||n.variant.length>12))throw new Error("Language variety is invalid");if(n.register!==void 0&&!["neutral","casual","formal"].includes(n.register))throw new Error("Register setting is invalid");if(o.reviewProvider!==void 0&&typeof o.reviewProvider!="string")throw new Error("Review model setting is invalid");if(t.usage!==void 0){const E=m(t.usage).monthlyLimit;if(E!==void 0&&(typeof E!="number"||!Number.isFinite(E)||E<0||E>1e5))throw new Error("Spending reminder is invalid")}if(Tt(t),!Number.isFinite(o.temperature)||typeof o.defaultProvider!="string")throw new Error("Model settings are incomplete");if(s.provider!=="selected"||typeof s.enabled!="boolean")throw new Error("Web lookup settings are invalid");if(!Number.isInteger(s.timeoutMs)||s.timeoutMs<2e3||s.timeoutMs>2e4)throw new Error("Web lookup timeout is invalid");if(!Number.isInteger(s.maxResults)||s.maxResults<1||s.maxResults>10)throw new Error("Web lookup result limit is invalid");if(typeof T.host!="string"||!Number.isInteger(T.port)||T.lan!==void 0&&typeof T.lan!="boolean")throw new Error("Server settings are invalid");if(t.memory!==void 0&&m(t.memory).consolidate!==void 0&&typeof m(t.memory).consolidate!="boolean")throw new Error("Memory settings are invalid");if(!Array.isArray(t.providers))throw new Error("The provider list does not match the current schema");const a=t.providers.find(E=>E?.id===re);if(t.providers.length!==Y.length+(a?1:0))throw new Error("The provider list does not match the current schema");if(a&&!at(a))throw new Error("The custom endpoint is invalid");const N=(a?[...Y,a]:Y).map(E=>{const l=m(t.providers.find(L=>L?.id===E.id));if(l.name!==E.name||l.kind!==E.kind||l.baseUrl!==E.baseUrl||l.apiKeySecret!==E.apiKeySecret)throw new Error(`Provider identity is invalid: ${E.id}`);if(typeof l.model!="string"||typeof l.enabled!="boolean")throw new Error(`Provider settings are incomplete: ${E.id}`);if(l.model.length>200||["__proto__","prototype","constructor"].includes(l.model.trim())||(l.enabled||l.capability)&&!l.model.trim())throw new Error(`Provider model is invalid: ${E.id}`);if(!Number.isInteger(l.contextWindowTokens)||l.contextWindowTokens<4096)throw new Error(`Context window is invalid: ${E.id}`);if(!Number.isInteger(l.maxOutputTokens)||l.maxOutputTokens<256)throw new Error(`Output limit is invalid: ${E.id}`);if(l.modelProfiles!==void 0){const L=m(l.modelProfiles);for(const[f,O]of Object.entries(L)){const v=m(O);if(!f.trim()||f.length>200||["__proto__","prototype","constructor"].includes(f))throw new Error(`Saved model name is invalid: ${E.id}`);if(!Number.isInteger(v.contextWindowTokens)||v.contextWindowTokens<4096)throw new Error(`Saved model context window is invalid: ${E.id}`);if(!Number.isInteger(v.maxOutputTokens)||v.maxOutputTokens<256)throw new Error(`Saved model output limit is invalid: ${E.id}`)}}if(l.capability){const L=l.capability,f=L.lookupReady===!0||E.id===re&&L.lookupReady===!1;if(L.conversationReady!==!0||!f||!Number.isInteger(L.contractVersion)||L.contractVersion<1||L.baseUrl.replace(/\/$/,"")!==l.baseUrl.replace(/\/$/,"")||L.model!==l.model||!["json_schema","json_object","prompt_json"].includes(L.outputMode)||typeof L.testedAt!="string")throw new Error(`Provider capability is stale or invalid: ${E.id}`)}if(l.price!==void 0){const L=m(l.price),f=O=>typeof O=="number"&&Number.isFinite(O)&&O>=0&&O<=1e4;if(!f(L.input)||!f(L.output))throw new Error(`Price is invalid: ${E.id}`)}return structuredClone(l)});if(o.defaultProvider&&!N.some(E=>E.id===o.defaultProvider))throw new Error("Default provider is invalid");if(o.reviewProvider&&!N.some(E=>E.id===o.reviewProvider))throw new Error("Review provider is invalid");return structuredClone(e)}function Ee(){return _(this,null,function*(){yield He()})}function X(e,t,r=384){return _(this,null,function*(){yield Ee();const n=`${e}.${process.pid}.${Je()}.tmp`;yield Ke(n,`${JSON.stringify(t,null,2)}
`),yield Ge(n,e)})}function Q(e){if(!e||typeof e!="object"||Array.isArray(e)||Object.values(e).some(t=>typeof t!="string"))throw new Error("Expected every secret value to be a string");return structuredClone(e)}function de(e){return e instanceof Error&&e.code==="ENOENT"}function le(e,t,r){return _(this,null,function*(){const n=yield We(e).catch(()=>{}),o=new Date(n?.mtimeMs||Date.now()).toISOString().replace(/[:.]/g,"-"),s=`${e}.broken-${o}`;return yield Be(e,s,Ue.COPYFILE_EXCL).catch(T=>{if(T.code!=="EEXIST")throw T}),Object.assign(new Error(`${t} is invalid. The original file was preserved and backed up to ${s}. Run "npm run doctor" for repair instructions.`,{cause:r}),{code:"LOCAL_CONFIG_INVALID",backupPath:s})})}let oe,ue=Promise.resolve();function Ne(e){const t=ue.then(e,e);return ue=t.then(()=>{},()=>{}),t}function ct(){return _(this,null,function*(){let e;try{e=yield ae(x,"utf8")}catch(t){if(de(t))return;throw t}try{const t=JSON.parse(e);if(t.version!==1)throw new Error("Unsupported provider transaction version");const r=P(t.config),n=Q(t.secrets);yield X(F,r),yield X(D,n),yield Oe(x)}catch(t){throw yield le(x,"Pending provider transaction",t)}})}function C(){return oe||=ct(),oe}function Et(){return _(this,null,function*(){yield Ee(),yield C();let e;try{e=yield ae(F,"utf8")}catch(n){if(!de(n))throw n;return yield X(F,W),structuredClone(W)}let t,r;try{t=JSON.parse(e),r=P(t)}catch(n){throw yield le(F,"Local configuration",n)}return r})}function dt(e){return _(this,null,function*(){const t=P(e);return yield C(),Ne(()=>_(null,null,function*(){return yield X(F,t),t}))})}function lt(e,t){return _(this,null,function*(){const r=P(e),n=Q(t);return yield C(),Ne(()=>_(null,null,function*(){yield X(x,{version:1,config:r,secrets:n});try{return yield X(F,r),yield X(D,n),yield Oe(x),r}catch(o){oe=void 0;try{return yield C(),r}catch(s){throw new AggregateError([o,s],"Could not persist the provider configuration transaction.")}}}))})}function Yt(){return _(this,arguments,function*(e={}){const t=structuredClone(W);return e.clearSecrets?yield ut(t,{}):yield k(t),t})}function Ae(){return _(this,null,function*(){yield Ee(),yield C();let e;try{e=yield ae(D,"utf8")}catch(t){if(!de(t))throw t;return yield X(D,{}),{}}try{return Q(JSON.parse(e))}catch(t){throw yield le(D,"Local secrets file",t)}})}function Nt(e,t){return _(this,null,function*(){yield C(),yield Ne(()=>_(null,null,function*(){const r=yield Ae();t?r[e]=t:delete r[e],yield X(D,r)}))})}const Lt={config:Et,saveConfig:dt,saveConfigAndSecrets:lt,secrets:Ae,setSecret:Nt},q=()=>Lt;function R(){return _(this,null,function*(){return q().config()})}function k(e){return _(this,null,function*(){return q().saveConfig(P(e))})}function ut(e,t){return _(this,null,function*(){return q().saveConfigAndSecrets(P(e),Q(t))})}function Kt(){return _(this,null,function*(){return q().secrets()})}const Ie=J,_t=200;class Le{#t;#e=new Map;constructor(t){this.#t=be(t)}#r(t){const r=this.#e.get(t);if(r)return this.#e.delete(t),this.#e.set(t,r),r;const n=this.#t.prepare(t);if(this.#e.set(t,n),this.#e.size>_t){const[o,s]=this.#e.entries().next().value;this.#e.delete(o),s.finalize()}return n}#n(t,r,n){const o=this.#r(t);try{return r.length&&o.bind(r),n(o)}finally{o.reset(!0)}}prepare(t){return{run:(...r)=>this.#n(t,r,n=>{for(;n.step(););return{changes:this.#t.changes(),lastInsertRowid:Pe(this.#t)}}),get:(...r)=>this.#n(t,r,n=>n.step()?n.get({}):void 0),all:(...r)=>this.#n(t,r,n=>{const o=[];for(;n.step();)o.push(n.get({}));return o})}}exec(t){this.#t.exec(t.replace(/PRAGMA\s+journal_mode\s*=\s*WAL\s*;?/giu,""))}close(){for(const t of this.#e.values())t.finalize();this.#e.clear(),ke(this.#t)}}let K=new Le(b.join(Ie,"app.db")),G,ye=()=>{};function B(){return G??ye()??K}const c={prepare:(...e)=>B().prepare(...e),exec:(...e)=>B().exec(...e),close:()=>B().close()};function mt(){c.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      mode TEXT NOT NULL,
      title TEXT NOT NULL,
      setup_json TEXT,
      interface_locale TEXT NOT NULL DEFAULT '',
      target_language TEXT NOT NULL DEFAULT '',
      target_language_code TEXT NOT NULL DEFAULT '',
      localized_setups_json TEXT NOT NULL DEFAULT '{}',
      state_json TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      archived_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_episodes (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      start_message_id TEXT NOT NULL,
      end_message_id TEXT NOT NULL,
      thread TEXT NOT NULL,
      summary TEXT NOT NULL,
      facts_json TEXT NOT NULL DEFAULT '[]',
      open_loops_json TEXT NOT NULL DEFAULT '[]',
      keywords_json TEXT NOT NULL DEFAULT '[]',
      topic_arcs_json TEXT NOT NULL DEFAULT '[]',
      interaction_signals_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      meta_json TEXT,
      client_message_id TEXT,
      reply_to_message_id TEXT,
      status TEXT NOT NULL DEFAULT 'complete',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS scene_anchors (
      id TEXT PRIMARY KEY,
      preset_id TEXT NOT NULL,
      target_language_code TEXT NOT NULL,
      raw_value TEXT NOT NULL,
      normalized_value TEXT NOT NULL,
      interface_locale TEXT NOT NULL DEFAULT '',
      confirmed_facts_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(preset_id, target_language_code, normalized_value)
    );
    CREATE TABLE IF NOT EXISTS scene_backgrounds (
      id TEXT PRIMARY KEY,
      anchor_id TEXT NOT NULL REFERENCES scene_anchors(id) ON DELETE CASCADE,
      preset_id TEXT NOT NULL,
      target_language_code TEXT NOT NULL,
      identity_key TEXT NOT NULL,
      stable_fingerprint TEXT NOT NULL,
      background_json TEXT NOT NULL,
      saved INTEGER NOT NULL DEFAULT 0,
      use_count INTEGER NOT NULL DEFAULT 0,
      last_used_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(anchor_id, identity_key)
    );
    CREATE TABLE IF NOT EXISTS scene_runs (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL UNIQUE REFERENCES conversations(id) ON DELETE CASCADE,
      anchor_id TEXT NOT NULL REFERENCES scene_anchors(id) ON DELETE CASCADE,
      background_id TEXT REFERENCES scene_backgrounds(id) ON DELETE SET NULL,
      preset_id TEXT NOT NULL,
      target_language_code TEXT NOT NULL,
      run_mode TEXT NOT NULL DEFAULT 'new_encounter',
      dynamic_fingerprint TEXT NOT NULL,
      opening_fingerprint TEXT NOT NULL,
      encounter_json TEXT NOT NULL,
      opening_line TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS word_entries (
      id TEXT PRIMARY KEY,
      term TEXT NOT NULL,
      lemma TEXT NOT NULL,
      language TEXT NOT NULL,
      interface_locale TEXT NOT NULL DEFAULT '',
      meaning TEXT NOT NULL,
      details_json TEXT NOT NULL,
      source_sentence TEXT,
      conversation_id TEXT,
      due_at TEXT NOT NULL,
      interval_days INTEGER NOT NULL DEFAULT 0,
      ease REAL NOT NULL DEFAULT 2.3,
      repetitions INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS memories (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL,
      key TEXT NOT NULL,
      semantic_slot TEXT NOT NULL DEFAULT '',
      value TEXT NOT NULL,
      interface_locale TEXT NOT NULL DEFAULT '',
      localized_values_json TEXT NOT NULL DEFAULT '{}',
      tier TEXT NOT NULL DEFAULT 'long_term',
      memory_type TEXT NOT NULL DEFAULT 'preference',
      topic TEXT NOT NULL DEFAULT 'general',
      importance REAL NOT NULL DEFAULT 0.5,
      pinned INTEGER NOT NULL DEFAULT 0,
      confidence REAL NOT NULL DEFAULT 1,
      sensitive INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'confirmed',
      source_conversation_id TEXT,
      source_message_id TEXT,
      supersedes_id TEXT,
      valid_from TEXT,
      valid_to TEXT,
      last_used_at TEXT,
      use_count INTEGER NOT NULL DEFAULT 0,
      last_mentioned_at TEXT,
      mention_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(category, key)
    );
    CREATE TABLE IF NOT EXISTS memory_revisions (
      id TEXT PRIMARY KEY,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      previous_value TEXT,
      next_value TEXT,
      change_type TEXT NOT NULL,
      source_conversation_id TEXT,
      source_message_id TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS memory_sources (
      id TEXT PRIMARY KEY,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      conversation_id TEXT,
      message_id TEXT,
      frame TEXT NOT NULL DEFAULT '',
      scene_title TEXT NOT NULL DEFAULT '',
      quote TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_memories (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      key TEXT NOT NULL,
      semantic_slot TEXT NOT NULL,
      value TEXT NOT NULL,
      quote TEXT NOT NULL DEFAULT '',
      about TEXT NOT NULL DEFAULT 'persona',
      durability TEXT NOT NULL DEFAULT 'momentary',
      memory_type TEXT NOT NULL DEFAULT 'preference',
      topic TEXT NOT NULL DEFAULT 'general',
      sensitive INTEGER NOT NULL DEFAULT 0,
      interface_locale TEXT NOT NULL DEFAULT '',
      source_message_id TEXT,
      promoted_memory_id TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(conversation_id, semantic_slot)
    );
    CREATE TABLE IF NOT EXISTS learning_events (
      id TEXT PRIMARY KEY,
      target_language_code TEXT NOT NULL,
      kind TEXT NOT NULL,
      category TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT '',
      original TEXT NOT NULL,
      improved TEXT NOT NULL,
      conversation_id TEXT,
      message_id TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS memory_suggestions (
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL,
      memory_id TEXT,
      conversation_memory_id TEXT,
      conversation_id TEXT,
      value TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      payload_json TEXT NOT NULL DEFAULT '{}',
      interface_locale TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL,
      resolved_at TEXT
    );
    CREATE TABLE IF NOT EXISTS app_flags (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS translation_cache (
      cache_key TEXT PRIMARY KEY,
      translation TEXT NOT NULL,
      hit_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      last_accessed TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ai_response_cache (
      cache_type TEXT NOT NULL,
      cache_key TEXT NOT NULL,
      response_json TEXT NOT NULL,
      hit_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      last_accessed TEXT NOT NULL,
      PRIMARY KEY (cache_type, cache_key)
    );
    CREATE TABLE IF NOT EXISTS web_lookup_cache (
      cache_key TEXT PRIMARY KEY,
      query TEXT NOT NULL,
      result_json TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_accessed TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS proficiency_profiles (
      language_code TEXT PRIMARY KEY,
      score REAL NOT NULL,
      working_step INTEGER NOT NULL,
      confidence TEXT NOT NULL DEFAULT 'low',
      skills_json TEXT NOT NULL DEFAULT '{}',
      source TEXT NOT NULL DEFAULT 'self',
      locked INTEGER NOT NULL DEFAULT 0,
      tested_at TEXT,
      tested_step INTEGER,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS proficiency_history (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      kind TEXT NOT NULL,
      from_step INTEGER,
      to_step INTEGER NOT NULL,
      reason TEXT NOT NULL,
      evidence_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS placement_sessions (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      language_name TEXT NOT NULL DEFAULT '',
      interface_locale TEXT NOT NULL DEFAULT '',
      mode TEXT NOT NULL DEFAULT 'full',
      status TEXT NOT NULL DEFAULT 'active',
      state_json TEXT NOT NULL DEFAULT '{}',
      result_json TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS placement_items (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      level TEXT NOT NULL,
      kind TEXT NOT NULL,
      item_json TEXT NOT NULL,
      use_count INTEGER NOT NULL DEFAULT 0,
      last_used_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS turn_signals (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      partner_message_id TEXT NOT NULL,
      user_message_id TEXT,
      language_code TEXT NOT NULL DEFAULT '',
      step INTEGER NOT NULL DEFAULT 0,
      length INTEGER NOT NULL DEFAULT 0,
      meaning_errors INTEGER NOT NULL DEFAULT 0,
      naturalness_errors INTEGER NOT NULL DEFAULT 0,
      non_target INTEGER NOT NULL DEFAULT 0,
      lookups INTEGER NOT NULL DEFAULT 0,
      translated INTEGER NOT NULL DEFAULT 0,
      simpler INTEGER NOT NULL DEFAULT 0,
      slower INTEGER NOT NULL DEFAULT 0,
      hints INTEGER NOT NULL DEFAULT 0,
      heard INTEGER NOT NULL DEFAULT 0,
      revealed INTEGER NOT NULL DEFAULT 0,
      lowered INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(conversation_id, partner_message_id)
    );
    CREATE TABLE IF NOT EXISTS conversation_assessments (
      conversation_id TEXT PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
      language_code TEXT NOT NULL,
      base_step INTEGER NOT NULL,
      estimate_step INTEGER NOT NULL,
      valid INTEGER NOT NULL DEFAULT 0,
      verdict TEXT NOT NULL DEFAULT 'fit',
      stats_json TEXT NOT NULL DEFAULT '{}',
      expression_step REAL,
      last_message_id TEXT,
      assessed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_recaps (
      conversation_id TEXT PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      last_message_id TEXT,
      content_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS practice_sets (
      id TEXT PRIMARY KEY,
      conversation_id TEXT REFERENCES conversations(id) ON DELETE CASCADE,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      items_json TEXT NOT NULL,
      answers_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS word_reviews (
      id TEXT PRIMARY KEY,
      word_id TEXT NOT NULL,
      language TEXT NOT NULL,
      rating INTEGER NOT NULL,
      source TEXT NOT NULL,
      conversation_id TEXT,
      state_before INTEGER NOT NULL DEFAULT 0,
      scheduled_days INTEGER NOT NULL DEFAULT 0,
      reviewed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversation_words (
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      word_id TEXT NOT NULL,
      term TEXT NOT NULL,
      meaning TEXT NOT NULL,
      source TEXT NOT NULL,
      arranged_at TEXT NOT NULL,
      used_at TEXT,
      result TEXT,
      message_id TEXT,
      PRIMARY KEY (conversation_id, word_id)
    );
    CREATE TABLE IF NOT EXISTS word_stories (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      step INTEGER NOT NULL,
      title TEXT NOT NULL,
      content_json TEXT NOT NULL,
      conversation_id TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS content_imports (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      step INTEGER NOT NULL,
      source_kind TEXT NOT NULL,
      source_url TEXT,
      source_title TEXT NOT NULL DEFAULT '',
      title TEXT NOT NULL,
      content_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS learning_paths (
      id TEXT PRIMARY KEY,
      language_code TEXT NOT NULL,
      interface_locale TEXT NOT NULL,
      items_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `)}function d(e,t,r){new Set(c.prepare(`PRAGMA table_info(${e})`).all().map(o=>o.name)).has(t)||c.exec(`ALTER TABLE ${e} ADD COLUMN ${t} ${r}`)}function ft(){d("turn_signals","heard","INTEGER NOT NULL DEFAULT 0"),d("turn_signals","revealed","INTEGER NOT NULL DEFAULT 0"),d("conversations","interface_locale","TEXT NOT NULL DEFAULT ''"),d("conversations","localized_setups_json","TEXT NOT NULL DEFAULT '{}'"),d("conversations","target_language","TEXT NOT NULL DEFAULT ''"),d("conversations","target_language_code","TEXT NOT NULL DEFAULT ''"),d("conversation_episodes","topic_arcs_json","TEXT NOT NULL DEFAULT '[]'"),d("conversation_episodes","interaction_signals_json","TEXT NOT NULL DEFAULT '[]'"),d("word_entries","interface_locale","TEXT NOT NULL DEFAULT ''"),d("word_entries","fsrs_json","TEXT NOT NULL DEFAULT ''"),d("conversations","material_json","TEXT NOT NULL DEFAULT ''"),d("memories","interface_locale","TEXT NOT NULL DEFAULT ''"),d("memories","localized_values_json","TEXT NOT NULL DEFAULT '{}'"),d("memories","semantic_slot","TEXT NOT NULL DEFAULT ''"),d("memories","tier","TEXT NOT NULL DEFAULT 'long_term'"),d("memories","memory_type","TEXT NOT NULL DEFAULT 'preference'"),d("memories","topic","TEXT NOT NULL DEFAULT 'general'"),d("memories","importance","REAL NOT NULL DEFAULT 0.5"),d("memories","pinned","INTEGER NOT NULL DEFAULT 0"),d("memories","source_message_id","TEXT"),d("memories","supersedes_id","TEXT"),d("memories","valid_from","TEXT"),d("memories","valid_to","TEXT"),d("memories","last_used_at","TEXT"),d("memories","use_count","INTEGER NOT NULL DEFAULT 0"),d("memories","last_mentioned_at","TEXT"),d("memories","mention_count","INTEGER NOT NULL DEFAULT 0"),d("memories","target_language_code","TEXT NOT NULL DEFAULT ''"),d("conversations","consolidated_message_id","TEXT"),d("conversations","difficulty_json","TEXT"),c.exec(`
    UPDATE memories SET valid_from = created_at WHERE valid_from IS NULL;
    UPDATE memories SET memory_type = 'learning' WHERE category = 'learning' AND memory_type = 'preference';
  `),c.exec(`
    UPDATE OR IGNORE memories SET memory_type = 'plan', category = 'plan' WHERE category = 'scene' OR memory_type = 'episodic';
    UPDATE OR IGNORE memories SET category = 'about' WHERE category = 'personal';
  `)}function Re(){if(c.prepare("SELECT 1 FROM app_flags WHERE key = 'memory_scope_review'").get())return;const e=new Date().toISOString(),t=c.prepare(`SELECT m.id AS id, m.source_conversation_id AS conversationId, m.source_message_id AS messageId,
    m.created_at AS createdAt, COALESCE(NULLIF(CASE WHEN json_valid(c.setup_json) THEN json_extract(c.setup_json, '$.title') END, ''), c.title) AS title, c.setup_json AS setupJson
    FROM memories m JOIN conversations c ON c.id = m.source_conversation_id
    WHERE NOT EXISTS (SELECT 1 FROM memory_sources s WHERE s.memory_id = m.id)`).all();c.exec("BEGIN IMMEDIATE");try{let r=0;for(const n of t){const o=!!(n.setupJson&&n.setupJson.trim()&&n.setupJson.trim()!=="null");r+=1,c.prepare(`INSERT INTO memory_sources (id, memory_id, conversation_id, message_id, frame, scene_title, quote, created_at)
        VALUES (?, ?, ?, ?, ?, ?, '', ?)`).run(`source-${n.id}-${r}`,n.id,n.conversationId,n.messageId,o?"scene":"direct",o&&n.title||"",n.createdAt||e),o&&c.prepare(`INSERT INTO memory_suggestions (id, kind, memory_id, conversation_id, status, created_at)
        VALUES (?, 'review', ?, ?, 'open', ?)`).run(`review-${n.id}`,n.id,n.conversationId,e)}c.prepare("INSERT INTO app_flags (key, value) VALUES ('memory_scope_review', ?)").run(e),c.exec("COMMIT")}catch(r){throw c.exec("ROLLBACK"),r}}function pt(){c.exec("CREATE UNIQUE INDEX IF NOT EXISTS messages_client_id_unique ON messages(conversation_id, client_message_id) WHERE client_message_id IS NOT NULL"),c.exec("CREATE UNIQUE INDEX IF NOT EXISTS messages_reply_to_unique ON messages(reply_to_message_id) WHERE reply_to_message_id IS NOT NULL"),c.exec("CREATE INDEX IF NOT EXISTS translation_cache_accessed_index ON translation_cache(last_accessed DESC)"),c.exec("CREATE INDEX IF NOT EXISTS ai_response_cache_accessed_index ON ai_response_cache(cache_type, last_accessed DESC)"),c.exec("CREATE INDEX IF NOT EXISTS conversation_episodes_conversation_index ON conversation_episodes(conversation_id, created_at)"),c.exec("CREATE INDEX IF NOT EXISTS scene_anchors_lookup_index ON scene_anchors(preset_id, target_language_code, normalized_value)"),c.exec("CREATE INDEX IF NOT EXISTS scene_backgrounds_anchor_index ON scene_backgrounds(anchor_id, use_count, last_used_at)"),c.exec("CREATE INDEX IF NOT EXISTS scene_runs_anchor_index ON scene_runs(anchor_id, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS scene_runs_preset_index ON scene_runs(preset_id, target_language_code, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS web_lookup_cache_expiry_index ON web_lookup_cache(expires_at)"),c.exec("DROP INDEX IF EXISTS memories_retrieval_index"),c.exec("CREATE INDEX memories_retrieval_index ON memories(status, tier, topic, updated_at DESC)"),c.exec("CREATE UNIQUE INDEX IF NOT EXISTS memories_semantic_slot_unique ON memories(semantic_slot) WHERE semantic_slot <> ''"),c.exec("CREATE INDEX IF NOT EXISTS memory_revisions_memory_index ON memory_revisions(memory_id, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS memory_sources_memory_index ON memory_sources(memory_id, created_at)"),c.exec("CREATE INDEX IF NOT EXISTS conversation_memories_conversation_index ON conversation_memories(conversation_id, updated_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS learning_events_language_index ON learning_events(target_language_code, kind, category, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS memory_suggestions_status_index ON memory_suggestions(status, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS proficiency_history_language_index ON proficiency_history(language_code, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS placement_items_lookup_index ON placement_items(language_code, interface_locale, level, kind, use_count)"),c.exec("CREATE INDEX IF NOT EXISTS turn_signals_conversation_index ON turn_signals(conversation_id, created_at)"),c.exec("CREATE INDEX IF NOT EXISTS conversation_assessments_language_index ON conversation_assessments(language_code, assessed_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS practice_sets_conversation_index ON practice_sets(conversation_id, created_at DESC)"),c.exec("CREATE INDEX IF NOT EXISTS word_entries_due_index ON word_entries(due_at)"),c.exec("CREATE INDEX IF NOT EXISTS word_reviews_time_index ON word_reviews(reviewed_at)"),c.exec("CREATE INDEX IF NOT EXISTS content_imports_time_index ON content_imports(created_at DESC)")}function we(){mt(),ft(),Re(),pt()}we();function Se(e="app.db"){return b.join(Ie,e)}function Fe(e){const t=G;G=e;try{we()}finally{G=t}}function H(e){K.close(),K=new Le(e),Fe(K)}function Ut(e){const t=new Le(e);return Fe(t),t}function Ot(e){ye=e}function gt(e){const t=new WeakMap;return()=>{const r=B();let n=t.get(r);return n||t.set(r,n=e()),n}}function ht(e,...t){return c.prepare(e).all(...t)}function Xt(e,...t){return c.prepare(e).get(...t)}var Gt=Object.freeze({__proto__:null,chooseDatabaseWith:Ot,databaseFile:Se,db:c,openDatabase:Ut,perDatabase:gt,reviewMemoriesFromScenes:Re,row:Xt,rows:ht,useDatabase:H}),w=(e,t,r)=>new Promise((n,o)=>{var s=i=>{try{a(r.next(i))}catch(N){o(N)}},T=i=>{try{a(r.throw(i))}catch(N){o(N)}},a=i=>i.done?n(i.value):Promise.resolve(i.value).then(s,T);a((r=r.apply(e,t)).next())});const _e=Ye("abcdefghijklmnopqrstuvwxyz0123456789",10),vt=40;let z=V;function At(){return z}function $(e){return Se(e===V?"app.db":`profile-${e}.db`)}function S(e){return e.profiles?.length?e.profiles:[{id:V,name:"",createdAt:""}]}function I(e){const t=S(e);return t.find(r=>r.id===e.activeProfile)?.id||t[0].id}function It(){return w(this,null,function*(){const e=I(yield R());e!==z&&(H($(e)),z=e)})}function y(e){const t=I(e);return{max:ce,profiles:S(e).map(r=>({id:r.id,name:r.name,createdAt:r.createdAt,active:r.id===t,targetLanguageCode:r.id===t?e.learning.targetLanguageCode:r.learning?.targetLanguageCode||""}))}}function h(e,t,r){return Object.assign(new Error(e),{statusCode:t,code:r})}function me(e){const t=typeof e=="string"?e.trim().replace(/\s+/gu," "):"";if(!t||t.length>vt)throw h("A profile needs a name of at most 40 characters.",400,"PROFILE_NAME_INVALID");return t}function ee(e){const{difficultyStep:t,...r}=e;return r}function yt(e,t){e.get("/api/profiles",()=>w(null,null,function*(){return y(yield R())})),e.post("/api/profiles",r=>w(null,null,function*(){const n=yield R(),o=S(n);if(o.length>=ce)throw h("No more profiles can be added.",409,"PROFILE_LIMIT");const s=me(r.body?.name);if(o.some(E=>E.name.toLowerCase()===s.toLowerCase()))throw h("A profile with this name exists.",409,"PROFILE_NAME_TAKEN");const T=ne.some(E=>E.code===r.body?.targetLanguageCode)?String(r.body.targetLanguageCode):n.learning.targetLanguageCode;let a=_e();for(;o.some(E=>E.id===a);)a=_e();const i={id:a,name:s,createdAt:new Date().toISOString(),learning:{...W.learning,targetLanguage:tt(T).name,targetLanguageCode:T},uiLocale:n.ui.locale},N=yield k({...n,profiles:[...o,i],activeProfile:I(n)});return{id:a,...y(N)}})),e.patch("/api/profiles/:id",r=>w(null,null,function*(){const n=yield R(),o=S(n);if(!o.some(a=>a.id===r.params.id))throw h("Profile not found",404,"PROFILE_NOT_FOUND");const s=me(r.body?.name);if(o.some(a=>a.id!==r.params.id&&a.name.toLowerCase()===s.toLowerCase()))throw h("A profile with this name exists.",409,"PROFILE_NAME_TAKEN");const T=yield k({...n,profiles:o.map(a=>a.id===r.params.id?{...a,name:s}:a),activeProfile:I(n)});return y(T)})),e.post("/api/profiles/:id/activate",r=>w(null,null,function*(){const n=yield R(),o=S(n),s=I(n),T=o.find(i=>i.id===r.params.id);if(!T)throw h("Profile not found",404,"PROFILE_NOT_FOUND");if(T.id===s)return y(n);if(t.busy())throw h("A reply is still being written. Switch once it has arrived.",409,"PROFILE_BUSY");const a={...n,profiles:o.map(i=>i.id===s?{...i,learning:ee(n.learning),uiLocale:n.ui.locale}:i.id===T.id?{id:i.id,name:i.name,createdAt:i.createdAt}:i),activeProfile:T.id,learning:T.learning?ee(T.learning):ee(n.learning),ui:{...n.ui,locale:T.uiLocale||n.ui.locale}};H($(T.id));try{const i=yield k(a);return z=T.id,y(i)}catch(i){throw H($(s)),i}})),e.delete("/api/profiles/:id",r=>w(null,null,function*(){const n=yield R(),o=S(n),s=o.find(i=>i.id===r.params.id);if(!s)throw h("Profile not found",404,"PROFILE_NOT_FOUND");if(s.id===I(n))throw h("The profile in use cannot be deleted. Switch to another first.",409,"PROFILE_IN_USE");const T=yield k({...n,profiles:o.filter(i=>i.id!==s.id),activeProfile:I(n)}),a=$(s.id);return yield Promise.all([a,`${a}-wal`,`${a}-shm`].map(i=>$e(i,{force:!0}))),y(T)}))}var Bt=Object.freeze({__proto__:null,activeProfileId:At,openActiveProfile:It,registerProfileRoutes:yt});export{kt as A,yt as B,re as C,Le as D,Yt as E,It as F,st as G,Mt as H,Gt as I,Bt as J,ne as T,Ie as a,ae as b,Ct as c,c as d,Je as e,Pt as f,bt as g,tt as h,R as i,Kt as j,Ft as k,jt as l,He as m,et as n,St as o,b as p,Dt as q,Xt as r,ht as s,xt as t,Oe as u,wt as v,gt as w,k as x,At as y,ut as z};
