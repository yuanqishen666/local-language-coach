import{_ as o}from"./Fold.vue_vue_type_script_setup_true_lang-DEaIizpF.js";import"./Icon.vue_vue_type_script_setup_true_lang-VCh1abay.js";import"./index-N7fTgw_g.js";export{o as default};
