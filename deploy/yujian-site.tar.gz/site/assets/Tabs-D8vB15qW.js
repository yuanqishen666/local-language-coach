import{_ as o}from"./Tabs.vue_vue_type_script_setup_true_lang-Y1BBzlyA.js";import"./index-N7fTgw_g.js";import"./Icon.vue_vue_type_script_setup_true_lang-VCh1abay.js";export{o as default};
